### Infoya steps definitions project for Opear application

## Intructions

# 1 Install the libraries using  the following commnad 

``` pip install git+https://github.com/JmatamorosInfoya/PythonWinOperaLibrary.git ```

# 2  Install python-dot env in your feature project

```
pip install python-dotenv
 ```

 # 3 Configure your .env enviroment file 
```
 WIN_ACCESS_DRIVER=absolute-path-to-windowsAccessBridge-File.dll
  ```
